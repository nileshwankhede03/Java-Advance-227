package com.Array;
import java.util.Arrays;

//  Array 
		// it is collection of similar datatype
		// size of array is fixed
		//  import Java.util Package
public class Arrayexample {

	public static void main(String[] args) {
//	int [] numbers = {10,20,30,40};
//	System.out.println(Arrays.toString(numbers));
//	int number1 [] = new int[5];
//	number1[0]= 50;
//	number1[1] = 60;
//	number1[2]= 70;
//	number1[3] = 80;
////	number1[4] = 90;
////	number1[5] = 100 ;
//	System.out.println(Arrays.toString(number1));
//	for (int num  : number1) {
//		System.out.println(num);
		
		int [] numbers = {10,40,30,10,50};
		int[] number5 = {10,40,30,10,50,20};
		System.out.println(Arrays.toString(numbers));	
		System.out.println(Arrays.toString(number5));	

		
//		int fdata = numbers[-1];
//		System.out.println(fdata);
		
//		numbers[1]= 100;
//		System.out.println(Arrays.toString(numbers));	
		
//		int number2 [] = Arrays.copyOf(numbers, 4);
//		System.out.println(Arrays.toString(number2));
//		
//		int number3 [] = Arrays.copyOfRange(numbers, 0, 3) ;
//		System.out.println(Arrays.toString(number3));
		
//		System.out.println(Arrays.binarySearch(numbers, 10));
		
//		System.out.println(numbers.length);
		
//		Arrays.sort(numbers);
//		System.out.println(Arrays.toString(numbers));
		
		System.out.println(Arrays.equals(numbers, number5));
		
		int prime []= {3,5,7,11};
		int max = 0;
		for (int i = 0; i< prime.length;i++) {
			if (max <prime[i]) {
				max  = prime[i];
				
			}
			
		}
		System.out.println(max);

			
	}

	
	
	}



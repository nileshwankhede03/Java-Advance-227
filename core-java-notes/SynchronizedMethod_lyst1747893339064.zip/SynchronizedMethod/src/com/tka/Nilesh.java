package com.tka;

public class Nilesh extends Thread {

	Radio r;

	public Nilesh(Radio obj) {
		r = obj;
	}

	@Override
	public void run() {
		r.play(92.1F);
	}

}
